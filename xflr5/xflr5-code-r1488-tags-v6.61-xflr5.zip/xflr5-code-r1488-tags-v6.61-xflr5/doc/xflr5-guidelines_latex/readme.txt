*** About ***

This latex version of the guidelines has been initiated from the
Guidelines_v604.odt found in the xflr5-6.09-04-svn branch.

The initial tex import has been made with w2l (OpenOffice or
LibreOffice writer2latex). Then it has been edited to be more human
readable.

This is not an official version yet.


*** Compilation ***

The compilation has been tested with the texlive distribution
(http://www.tug.org/texlive/) under Windows and GNU/Linux/Ubuntu. Old
tetex distribution don't handle correctly the png transparency.

The compilation needs three pass to succeed (generation of
layout+references). There is a sample makefile for unix systems.

*** Edition ***

The texlive distribution include a tex editor. Most of my colleague
use texmaker under Windows. I personnaly use emacs+auctex under
GNU/Linux.

Setup your editor with automatic filling at 80.

*** TODO ***

This document doesn't replace the official Guidelines.odt yet. Indeed,
it needs some improvements : 
- homogeneisation of symbols typo.  
- check references, and credits 
- ...
