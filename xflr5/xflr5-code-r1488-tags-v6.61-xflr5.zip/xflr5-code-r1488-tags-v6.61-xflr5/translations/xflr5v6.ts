<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AFoil</name>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="166"/>
        <source>Spline foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="480"/>
        <source>Foil has been de-rotated by %1 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="508"/>
        <source>Foil has been normalized from %1  to 1.000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="848"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1089"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1095"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1352"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1358"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="848"/>
        <source>At least two foils are required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1009"/>
        <source>Are you sure you want to delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1010"/>
        <source>and all associated OpPoints and Polars ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1012"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1258"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1053"/>
        <source>Export Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1055"/>
        <source>Foil File (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1076"/>
        <source>Spline Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1088"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1351"/>
        <source>Too many output points on upper surface
 Max =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1094"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1357"/>
        <source>Too many output points on lower surface
 Max =%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1101"/>
        <source>Export Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1103"/>
        <source>Text File (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1258"/>
        <source>Discard changes to Splines ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1292"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1822"/>
        <source>Enter the foil&apos;s new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1507"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1508"/>
        <source>Thickness (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1509"/>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1511"/>
        <source>at (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1510"/>
        <source>Camber (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1512"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1513"/>
        <source>TE Flap (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1514"/>
        <source>TE XHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1515"/>
        <source>TE YHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1516"/>
        <source>LE Flap (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1517"/>
        <source>LE XHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1518"/>
        <source>LE YHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1519"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1520"/>
        <source>Centerline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1521"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoil.cpp" line="1523"/>
        <source>Foils</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AFoilTableDlg</name>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="36"/>
        <source>Foil Table Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="96"/>
        <source>Foil Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="97"/>
        <source>Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="98"/>
        <source>Thickness max. position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="99"/>
        <source>Camber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="100"/>
        <source>Camber max. position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="101"/>
        <source>Number of points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="102"/>
        <source>Trailing edge flap angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="103"/>
        <source>Trailing edge hinge x-position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="104"/>
        <source>Trailing edge hinge y-position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="105"/>
        <source>Leading edge flap angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="106"/>
        <source>Leading edge hinge x-position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="107"/>
        <source>Leading edge hinge y-position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="125"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/afoiltabledlg.cpp" line="126"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutQ5</name>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="60"/>
        <source>Copyright (C) M. Drela and H. Youngren 2000 - XFoil v6.94</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="61"/>
        <source>Copyright (C) Matthieu Scherrer 2004 - Miarex v1.00</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="33"/>
        <source>About XFLR5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="62"/>
        <source>Copyright (C) Andre Deperrois 2003-2019</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="63"/>
        <source>This program is distributed in the hope that it will be useful,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="64"/>
        <source>but WITHOUT ANY WARRANTY; without even the implied warranty of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="65"/>
        <source>MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="68"/>
        <source>Program distributed  under the terms of the GNU General Public License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="69"/>
        <source>German translation by Christall, Jochen Günzel and Martin Willner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="70"/>
        <source>Japanese translation by IKUSU, Koichi Akabe, Misatus, dynamicsoar, hide253</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="71"/>
        <source>icchy_07, ina111, ohayo_cycling, ohisa_64, ozawa64.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/aboutq5.cpp" line="72"/>
        <source>French translation by Jean-Luc Coulon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AeroDataDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="46"/>
        <source>Air data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="141"/>
        <source>Applicable in the troposphere
 i.e. Altitude &lt; 11000m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="148"/>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="149"/>
        <source>Altitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="150"/>
        <source>Air Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="151"/>
        <source>Air Density</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="152"/>
        <source>Dynamic Viscosity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="153"/>
        <source>Kinematic Viscosity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="154"/>
        <source>Speed of Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="227"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/aerodatadlg.cpp" line="228"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatchDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="105"/>
        <source>Iter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="160"/>
        <source>Current foil only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="161"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="162"/>
        <source>Foil list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="156"/>
        <source>Foil Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="175"/>
        <source>Type 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="176"/>
        <source>Type 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="177"/>
        <source>Type 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="178"/>
        <source>Type 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="171"/>
        <source>Analysis Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="60"/>
        <source>Batch foil analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="191"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="192"/>
        <source>Re List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="193"/>
        <source>Edit List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="194"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="259"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="195"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="260"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="196"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="261"/>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="187"/>
        <source>Batch Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="255"/>
        <source>Specify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="256"/>
        <source>Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="257"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="258"/>
        <source>From Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="265"/>
        <source>Spec =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="251"/>
        <source>Analysis Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="209"/>
        <source>NCrit=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="231"/>
        <source>Forced transitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="307"/>
        <source>Store OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="319"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="320"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="444"/>
        <source>Analyze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="290"/>
        <source>Skip Opp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="291"/>
        <source>Skip Polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="408"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="1097"/>
        <source>Analysis interrupted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="709"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="766"/>
        <source>Reynolds =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="710"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="724"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="731"/>
        <source>Mach =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="237"/>
        <source>Top transition location (x/c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="238"/>
        <source>Bottom transition location (x/c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="303"/>
        <source>Initialize the boundary layer after each polar calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="304"/>
        <source>Initialize the boundary layer after unconverged points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="288"/>
        <source>Max. iterations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="284"/>
        <source>Iterations control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="683"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="730"/>
        <source>Alpha =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="692"/>
        <source>Cl =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="716"/>
        <source>Re.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="717"/>
        <source>Ma.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="723"/>
        <source>Re.Cl =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="824"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="1174"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="910"/>
        <source>Foils to analyze:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="1193"/>
        <source>Analyzing </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="1214"/>
        <source> ...some points are unconverged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchdlg.cpp" line="1217"/>
        <source>Analysis completed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatchThreadDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="62"/>
        <source>Multi-threaded batch analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="156"/>
        <source>Foil Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="159"/>
        <source>Current foil only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="160"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="161"/>
        <source>Foil list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="169"/>
        <source>Batch Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="173"/>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="174"/>
        <source>Re List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="175"/>
        <source>Edit List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="176"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="242"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="177"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="243"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="178"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="244"/>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="185"/>
        <source>NCrit=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="225"/>
        <source>Analysis Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="229"/>
        <source>Specify:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="230"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="581"/>
        <source>Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="231"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="232"/>
        <source>From Zero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="248"/>
        <source>Spec =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="269"/>
        <source>Forced Transitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="275"/>
        <source>Top transition location (x/c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="276"/>
        <source>Bottom transition location (x/c)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="327"/>
        <source>Initialize BLs between polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="331"/>
        <source>Update polar view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="953"/>
        <source>Found %1 foil/polar pairs to analyze
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="961"/>
        <source>Starting with %1 threads

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="963"/>
        <source>
Started/Done/Total
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="989"/>
        <source>
_____Analysis cancelled_____
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="990"/>
        <source>
_____Analysis completed_____
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="1039"/>
        <source>Starting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="1072"/>
        <source>   ...Finished </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="1090"/>
        <source>Foils to analyze:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="1104"/>
        <source>Reynolds numbers to analyze:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="291"/>
        <source>Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="294"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="295"/>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="379"/>
        <source>Analyze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="332"/>
        <source>Update the polar graphs after the completion of each foil/polar pair.
Uncheck for increased analysis speed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="333"/>
        <source>Clear Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="341"/>
        <source>Max. Threads to use for the analysis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="589"/>
        <source>CL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/batchthreaddlg.cpp" line="920"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BodyFrameWt</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="350"/>
        <source>X-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="351"/>
        <source>Y-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="352"/>
        <source>x  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="353"/>
        <source>y  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="363"/>
        <source>Scale Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="371"/>
        <source>Insert Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="375"/>
        <source>Remove Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="383"/>
        <source>Show Current Frame Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="388"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="392"/>
        <source>Grid Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="400"/>
        <source>Load background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodyframewt.cpp" line="404"/>
        <source>Clear background image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BodyGridDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="69"/>
        <source>Body Grid Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="114"/>
        <source>Grid Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="116"/>
        <source>Show Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="117"/>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="118"/>
        <source>Main Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="119"/>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="120"/>
        <source>Minor Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="141"/>
        <source>Body Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="157"/>
        <source>Frame Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="175"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodygriddlg.cpp" line="176"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BodyLineWt</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="277"/>
        <source>X-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="278"/>
        <source>Y-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="279"/>
        <source>x  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="280"/>
        <source>y  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="291"/>
        <source>Scale Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="299"/>
        <source>Insert Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="303"/>
        <source>Remove Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="311"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="315"/>
        <source>Grid Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="323"/>
        <source>Load background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/bodylinewt.cpp" line="327"/>
        <source>Clear background image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BodyScaleDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="38"/>
        <source>Body Scale Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="90"/>
        <source>Whole Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="91"/>
        <source>Frame Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="107"/>
        <source>Scale Factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="108"/>
        <source>X Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="109"/>
        <source>Y Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="110"/>
        <source>Z Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="122"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodyscaledlg.cpp" line="123"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BodyTransDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="36"/>
        <source>Body Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="120"/>
        <source>Frame Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="128"/>
        <source>X Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="129"/>
        <source>Y Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="130"/>
        <source>Z Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="150"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/bodytransdlg.cpp" line="151"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CAddDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="37"/>
        <source>Local Panel Refinement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="61"/>
        <source>Angle Criterion </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="62"/>
        <source>Type of Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="63"/>
        <source>Refinement X Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="64"/>
        <source>From</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="65"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="72"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="73"/>
        <source>Arc Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="105"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="106"/>
        <source>Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="107"/>
        <source>MaxAngle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="108"/>
        <source>At Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="90"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="91"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="92"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="146"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="146"/>
        <source>Unrecognized foil format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="160"/>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="220"/>
        <source>Total number of points is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="162"/>
        <source>(added %1 points to original foil)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="175"/>
        <source>Maximum panel angle is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="177"/>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="217"/>
        <source>at panel position %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/cadddlg.cpp" line="215"/>
        <source>Maximum panel angle is %1 deg</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditBodyDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="80"/>
        <source>Insert before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="81"/>
        <source>Insert after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="82"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="84"/>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="99"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="102"/>
        <source>Export Body Geometry to text File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="105"/>
        <source>Export body definition to an XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="109"/>
        <source>Import body definition from an XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="112"/>
        <source>Define Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="115"/>
        <source>Translate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="203"/>
        <source>Insert body frame before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="204"/>
        <source>Insert body frame after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="205"/>
        <source>Delete body frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="209"/>
        <source>Insert point mass before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="210"/>
        <source>Insert point mass after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="211"/>
        <source>Delete point Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="221"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="221"/>
        <source>Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="221"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="221"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="236"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="278"/>
        <source>Regenerate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="280"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="282"/>
        <source>Actions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="315"/>
        <source>Axes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="316"/>
        <source>Surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="317"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="318"/>
        <source>Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="319"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="350"/>
        <source>X View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="351"/>
        <source>Y View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="352"/>
        <source>Z View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="353"/>
        <source>Iso View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="354"/>
        <source>Flip View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="372"/>
        <source>Reset scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1351"/>
        <source>Export plane definition to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1381"/>
        <source>Open XML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1383"/>
        <source>Plane XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1391"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1392"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="524"/>
        <source>Save the changes ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="525"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditPlaneDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="82"/>
        <source>Insert Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="83"/>
        <source>Insert after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="84"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="86"/>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="192"/>
        <source>Insert body frame before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="193"/>
        <source>Insert body frame after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="194"/>
        <source>Delete body frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="198"/>
        <source>Insert wing section before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="199"/>
        <source>Insert wing section after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="200"/>
        <source>Delete wing section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="204"/>
        <source>Insert point mass before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="205"/>
        <source>Insert point mass after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="206"/>
        <source>Delete point Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="222"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="222"/>
        <source>Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="222"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="222"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="237"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="307"/>
        <source>Axes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="308"/>
        <source>Surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="309"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="310"/>
        <source>Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="311"/>
        <source>Foil Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="312"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="344"/>
        <source>X View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="345"/>
        <source>Y View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="346"/>
        <source>Z View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="347"/>
        <source>Iso View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="348"/>
        <source>Flip View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="368"/>
        <source>Reset scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="372"/>
        <source>Clip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="410"/>
        <source>Auto regeneration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="411"/>
        <source>Regenerate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="621"/>
        <source>Save the changes ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="622"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="499"/>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1798"/>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1985"/>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1993"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1798"/>
        <source>No insertion possible before the first section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1985"/>
        <source>The wing&apos;s first section cannot be deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="1993"/>
        <source>The wing cannot have less than two sections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2089"/>
        <source>Wing Span      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2094"/>
        <source>xyProj. Span   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2099"/>
        <source>Wing Area      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2104"/>
        <source>xyProj. Area   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2110"/>
        <source>Plane Mass     =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2116"/>
        <source>Wing Load      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2123"/>
        <source>Tail Volume    =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2128"/>
        <source>Root Chord     =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2133"/>
        <source>MAC            =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2138"/>
        <source>TipTwist       =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2142"/>
        <source>Aspect Ratio   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2146"/>
        <source>Taper Ratio    =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2150"/>
        <source>Root-Tip Sweep =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editplanedlg.cpp" line="2154"/>
        <source>TailVolume     =</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditPlrDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/editplrdlg.cpp" line="45"/>
        <source>Polar Points Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/editplrdlg.cpp" line="291"/>
        <source>Delete All Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/editplrdlg.cpp" line="293"/>
        <source>Delete Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/editplrdlg.cpp" line="294"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/editplrdlg.cpp" line="295"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditPolarDefDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="92"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="92"/>
        <source>Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="92"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="92"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="107"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="138"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/editpolardefdlg.cpp" line="140"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlapDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="35"/>
        <source>Flap Dlg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="76"/>
        <source>L.E. Flap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="77"/>
        <source>T.E. Flap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="85"/>
        <source>Flap Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="86"/>
        <source>+ is down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="87"/>
        <source>Hinge X Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="88"/>
        <source>% Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="89"/>
        <source>Hinge Y Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="90"/>
        <source>% Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="110"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="111"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="112"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="161"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/flapdlg.cpp" line="161"/>
        <source>The trailing edge hinge must be downstream of the leading edge hinge</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FoilCoordDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="317"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="36"/>
        <source>Foil Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="314"/>
        <source>Insert Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="315"/>
        <source>Delete Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="316"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="318"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="319"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FoilDesignWt</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/foildesignwt.cpp" line="462"/>
        <location filename="../xflr5-gui/viewwidgets/foildesignwt.cpp" line="476"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/foildesignwt.cpp" line="462"/>
        <location filename="../xflr5-gui/viewwidgets/foildesignwt.cpp" line="476"/>
        <source>The minimum number of control points has been reached for this spline degree</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FoilGeomDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="39"/>
        <source>Foil Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="77"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="140"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="78"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="82"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="141"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="145"/>
        <source>%Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="79"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="83"/>
        <source>0%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="80"/>
        <source>10%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="81"/>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="144"/>
        <source>Max x-pos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="84"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="63"/>
        <source>Camber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="126"/>
        <source>Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="192"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="193"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="194"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="281"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilgeomdlg.cpp" line="281"/>
        <source>Panel number cannot exceed 300</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FoilPolarDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="43"/>
        <source>Foil Polar Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="70"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="71"/>
        <source>User Defined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="64"/>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="72"/>
        <source>Analysis Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="89"/>
        <source>Type 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="90"/>
        <source>Type 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="91"/>
        <source>Type 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="92"/>
        <source>Type 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="85"/>
        <source>Analysis Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="108"/>
        <source>Plane Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="115"/>
        <source>Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="116"/>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="117"/>
        <source>Span</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="137"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="138"/>
        <source>International</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="139"/>
        <source>Imperial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="173"/>
        <source>  Re =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="175"/>
        <source> </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="177"/>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="463"/>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="481"/>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="490"/>
        <source>Mach =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="101"/>
        <source>Reynolds and Mach Numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="211"/>
        <source>Free transitions (e^n) method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="212"/>
        <source>Forced transition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="213"/>
        <source>NCrit=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="214"/>
        <source>TripLocation (top)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="215"/>
        <source>TripLocation (bot)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="207"/>
        <source>Transition settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="133"/>
        <source>Fluid properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="322"/>
        <source>Analysis parameters for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="461"/>
        <source>Reynolds =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="470"/>
        <source>Re.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="472"/>
        <source>Ma.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="479"/>
        <source>Re.Cl =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/foilpolardlg.cpp" line="488"/>
        <source>Alpha =</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FoilSelectionDlg</name>
    <message>
        <location filename="../xflr5-gui/xinverse/foilselectiondlg.cpp" line="33"/>
        <source>Foil Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/foilselectiondlg.cpp" line="50"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GL3DScales</name>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="48"/>
        <source>3D Scales Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="93"/>
        <source>Auto Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="98"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="99"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="89"/>
        <source>Cp Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="167"/>
        <source>Lift </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="168"/>
        <source>Drag </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="169"/>
        <source>Velocity </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="113"/>
        <source>Vector Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="217"/>
        <source>L.E.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="218"/>
        <source>T.E.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="219"/>
        <source>Y-Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="190"/>
        <source>X-axis points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="191"/>
        <source>1st segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="192"/>
        <source>X factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="220"/>
        <source>X-Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="221"/>
        <source>Z-Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="183"/>
        <source>Streamline length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="209"/>
        <source>Start Streamline at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="245"/>
        <source>Streamlines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gl3dscales.cpp" line="247"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GL3dBodyDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="77"/>
        <source>Body Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="108"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="109"/>
        <source>Grid Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="110"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="112"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1307"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="116"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1308"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="126"/>
        <source>Translate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="212"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="215"/>
        <source>NPanels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1036"/>
        <source>Body Dlg Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="113"/>
        <source>Cancels the last modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="117"/>
        <source>Restores the last cancelled modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="120"/>
        <source>Export Body Geometry to text File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="121"/>
        <source>Export Body Definition to txt File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="122"/>
        <source>Export body definition to an XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="123"/>
        <source>Import Body Definition from a text file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="124"/>
        <source>Import body definition from an XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="125"/>
        <source>Define Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="491"/>
        <source>Export plane definition to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="641"/>
        <source>Open XML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="643"/>
        <source>Plane XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="651"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="652"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="869"/>
        <source>The degree must be less than the number of Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="895"/>
        <source>The degree must be less than the number of side lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1036"/>
        <source>Save the Body ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1242"/>
        <source>Axes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1243"/>
        <source>Surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1244"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1245"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1408"/>
        <source>Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1246"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1310"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1312"/>
        <source>Actions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1393"/>
        <source>Flat Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1394"/>
        <source>BSplines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1405"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1406"/>
        <source>Hoop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1407"/>
        <source>Degree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1355"/>
        <source>BodyName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1376"/>
        <source>Enter here a short description for the body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1373"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1273"/>
        <source>X View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1274"/>
        <source>Y View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1275"/>
        <source>Z View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1276"/>
        <source>Iso View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1277"/>
        <source>Flip View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1298"/>
        <source>Reset Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1357"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1361"/>
        <source>Textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1362"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1389"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1409"/>
        <source>Panel bunch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1466"/>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1467"/>
        <source>Frame Positions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1487"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="1488"/>
        <source>Current Frame Definition</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GL3dWingDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="127"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="136"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="145"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="155"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="163"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="621"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="703"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1713"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1780"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1804"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="621"/>
        <source>The first section cannot be deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1284"/>
        <source>Symetric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1285"/>
        <source>Right Side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1286"/>
        <source>Left Side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="94"/>
        <source>Insert Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="70"/>
        <source>Wing Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="93"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="95"/>
        <source>Insert after</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="96"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1175"/>
        <source>Delete section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="97"/>
        <source>Reset section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="99"/>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="127"/>
        <source>Please enter a name for the wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="136"/>
        <source>Warning : Panel sequence is inconsistent. The sections should be ordered from root to tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="145"/>
        <source>Zero length chords will cause a division by zero and should be avoided.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="155"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="163"/>
        <source>Zero length flaps will cause a division by zero and should be avoided.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="177"/>
        <source>Only 10 flaps x 2 will be handled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="178"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1130"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="382"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="390"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1089"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1104"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="383"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="391"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1090"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1105"/>
        <source>Cosine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="392"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1091"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1106"/>
        <source>Sine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="393"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1092"/>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1107"/>
        <source>-Sine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="497"/>
        <source>y (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="498"/>
        <source>chord (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="499"/>
        <source>offset (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="703"/>
        <source>No insertion possible before the first section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1012"/>
        <source>Wing Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1129"/>
        <source>Save the changes ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1213"/>
        <source>Undefined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1260"/>
        <source>WingName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1264"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1265"/>
        <source>Textures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1345"/>
        <source>Wing Span</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1346"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1347"/>
        <source>Projected Span</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1348"/>
        <source>Projected Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1484"/>
        <source>X View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1485"/>
        <source>Y View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1486"/>
        <source>Z View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1487"/>
        <source>Iso View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1488"/>
        <source>Flip View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1506"/>
        <source>Reset scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1521"/>
        <source>Import Wing (deprecated, use XML)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1522"/>
        <source>Export Wing (deprecated, use XML)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1523"/>
        <source>Import Wing from xml file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1524"/>
        <source>Export Wing to xml file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1526"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1527"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1704"/>
        <source>Plane XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1712"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1749"/>
        <source>Export to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1167"/>
        <source>Insert after section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1171"/>
        <source>Insert before section</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1349"/>
        <source>Number of VLM Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1350"/>
        <source>Number of 3D Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1387"/>
        <source>Mean Geom. Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1388"/>
        <source>Mean Aero Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1389"/>
        <source>Aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1390"/>
        <source>Taper Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1391"/>
        <source>Root to Tip Sweep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1392"/>
        <source>Number of Flaps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1437"/>
        <source>Enter here a short description for the wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1439"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1448"/>
        <source>Axes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1449"/>
        <source>Surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1450"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1451"/>
        <source>Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1452"/>
        <source>Foil Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1453"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1516"/>
        <source>Reset Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1519"/>
        <source>Scale Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1520"/>
        <source>Inertia...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLLightDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="45"/>
        <source>OpenGL Light Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="86"/>
        <source>Diffuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="87"/>
        <source>Ambient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="88"/>
        <source>Specular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="81"/>
        <source>Light Intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="134"/>
        <source>Attenuation factor=1/(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="162"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="163"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="164"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="236"/>
        <source>Material Shininess</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="158"/>
        <source>Light Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="202"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="203"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="204"/>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="198"/>
        <source>Light Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="246"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="247"/>
        <source>Reset Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/gllightdlg.cpp" line="261"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GLRenderWindow</name>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/glrenderwindow.cpp" line="161"/>
        <source>makeCurrent() failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphDlg</name>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="49"/>
        <source>Graph Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="186"/>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="192"/>
        <source>X - Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="187"/>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="193"/>
        <source>Cp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="155"/>
        <source>Y - span</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="157"/>
        <source>Induced Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="158"/>
        <source>Total Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="159"/>
        <source>Local lift coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="160"/>
        <source>Local Lift C.Cl/M.A.C.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="161"/>
        <source>Airfoil viscous drag coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="162"/>
        <source>Induced drag coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="163"/>
        <source>Total drag coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="164"/>
        <source>Local Drag C.Cd/M.A.C.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="165"/>
        <source>Airfoil Pitching moment coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="166"/>
        <source>Total Pitching moment coef.</source>
        <oldsource>Geom. Pitching moment coef.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="167"/>
        <source>Reynolds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="168"/>
        <source>Top Transition x-pos%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="169"/>
        <source>Bottom Transition x-pos%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="170"/>
        <source>Centre of Pressure x-pos%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="171"/>
        <source>Bending moment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="756"/>
        <source>YAxis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="757"/>
        <source>vs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="758"/>
        <source>XAxis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="789"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="790"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="791"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="792"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="809"/>
        <source>Title Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="811"/>
        <source>Label Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="785"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="823"/>
        <source>Graph Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="825"/>
        <source>Graph Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="819"/>
        <source>BackGround</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="842"/>
        <source>Padding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="846"/>
        <source>Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="847"/>
        <source>pixels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="871"/>
        <source>X Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="872"/>
        <source>Y Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="876"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="877"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="878"/>
        <source>Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="879"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="890"/>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="904"/>
        <source>Auto Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="903"/>
        <source>Inverted Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="926"/>
        <source>Axis Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="928"/>
        <source>X Major Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="929"/>
        <source>Y Major Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="930"/>
        <source>X Minor Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="931"/>
        <source>Y Minor Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="932"/>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="933"/>
        <source>Auto Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="966"/>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="967"/>
        <source>Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="968"/>
        <source>Axis and Grids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/graph/graphdlg.cpp" line="969"/>
        <source>Fonts and BackGround</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphWidget</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/graphwidget.cpp" line="368"/>
        <source>Cp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/graphwidget.cpp" line="373"/>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GridSettingsDlg</name>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="35"/>
        <source>Grid Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="153"/>
        <source>Neutral Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="154"/>
        <source>X-Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="155"/>
        <source>X Major Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="156"/>
        <source>Y Major Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="157"/>
        <source>X Minor Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="158"/>
        <source>Y Minor Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="196"/>
        <source>Accept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/gridsettingsdlg.cpp" line="197"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportObjectDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/importobjectdlg.cpp" line="36"/>
        <source>Import Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/importobjectdlg.cpp" line="47"/>
        <source>Select the wing to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/importobjectdlg.cpp" line="62"/>
        <source>Select the body to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/importobjectdlg.cpp" line="103"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/importobjectdlg.cpp" line="105"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InertiaDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="48"/>
        <source>Inertia Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="352"/>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="353"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="354"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="355"/>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="356"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="378"/>
        <source>Wing Mass:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="390"/>
        <source>Body Mass:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="409"/>
        <source>Volume Mass:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="601"/>
        <source>%1 %2 %3 %4 %5 %6 %7 %8 %9 %10 ! </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="842"/>
        <source>This is a calculation form for a rough order of magnitude for the inertia tensor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="508"/>
        <source>Export Mass Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="62"/>
        <source>Insert Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="63"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="65"/>
        <source>Point Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="380"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="392"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="416"/>
        <source>Inertia properties for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="509"/>
        <source>AVL Mass File (*.mass)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="567"/>
        <source>%1 %2 %3 %4 %5 %6 %7 %8 %9 %10! Inertia of both left and right wings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="580"/>
        <source>%1 %2 %3 %4 %5 %6 %7 %8 %9 %10 ! Body inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="620"/>
        <source>%1 %2 %3 %4 %5 %6 %7 %8 %9 %10 ! Body&apos;s inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="843"/>
        <source>Refer to the Guidelines for explanations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="850"/>
        <source>Object Mass - Volume only, excluding point masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="853"/>
        <source>Wing Mass=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="952"/>
        <source>Component inertias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="956"/>
        <source>Main Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="957"/>
        <source>Second Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="958"/>
        <source>Elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="959"/>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="960"/>
        <source>Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1010"/>
        <source>Additional Point Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1044"/>
        <source>Total Mass = Volume + point masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1047"/>
        <source>Total Mass=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="857"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="861"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1052"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1056"/>
        <source>Center of gravity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="902"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="922"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1096"/>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1116"/>
        <source>Inertia in CoG Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/inertiadlg.cpp" line="1149"/>
        <source>Export to AVL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InterpolateFoilsDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="39"/>
        <source>Interpolate Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="62"/>
        <source>Camb1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="63"/>
        <source>Camb2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="91"/>
        <source>Camb3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="64"/>
        <source>Thick1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="65"/>
        <source>Thick2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="93"/>
        <source>Thick3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="107"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="108"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="206"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="235"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="292"/>
        <source>Camb.=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="208"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="215"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="237"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="244"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="294"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="301"/>
        <source> at x=%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="213"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="242"/>
        <location filename="../xflr5-gui/xdirect/geometry/interpolatefoilsdlg.cpp" line="299"/>
        <source>Thick.=%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InverseOptionsDlg</name>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="33"/>
        <source>XInverse Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="43"/>
        <source>Reference Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="44"/>
        <source>Modified Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="45"/>
        <source>Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="46"/>
        <source>Reflected Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="70"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/inverseoptionsdlg.cpp" line="71"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LECircleDlg</name>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="33"/>
        <source>L.E. Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="43"/>
        <source>r=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="44"/>
        <source>% Chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="52"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="56"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/lecircledlg.cpp" line="57"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LEDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="36"/>
        <source>Leading Edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="59"/>
        <source>Approximate new/old ratio for L.E. radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="62"/>
        <source>ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="72"/>
        <source>Blending Distance from L.E.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="75"/>
        <source>% chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="85"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="86"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="87"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="192"/>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="203"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="192"/>
        <source>Unrecognized foil format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/ledlg.cpp" line="203"/>
        <source>Panel number cannot exceed 300</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LLTAnalysisDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="59"/>
        <source>LLT Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="237"/>
        <source>Launching analysis....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="239"/>
        <source>Max iterations     = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="241"/>
        <source>Alpha precision    = %1 deg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="245"/>
        <source>Relaxation factor  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="243"/>
        <source>Number of stations = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="188"/>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="191"/>
        <source>Keep this window opened on errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="302"/>
        <source>Analysis completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="303"/>
        <source> ...some points are outside the flight envelope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="304"/>
        <source> ...some points are unconverged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/lltanalysisdlg.cpp" line="330"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Language</name>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="115"/>
        <source>English</source>
        <translation>English</translation>
    </message>
</context>
<context>
    <name>LanguageWt</name>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="39"/>
        <source>Language settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="40"/>
        <source>English</source>
        <translation type="unfinished">English</translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="48"/>
        <source>Select the application&apos;s default language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="139"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/languagewt.cpp" line="139"/>
        <source>The language change will take effect at the next session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LengthUnitDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="33"/>
        <source>Select units for this project :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="34"/>
        <source>Units Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="45"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="50"/>
        <source>Define the project units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="76"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/lengthunitdlg.cpp" line="77"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LinePickerDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="39"/>
        <source>Line Picker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="268"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="269"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="270"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="271"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="307"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/line/linepickerdlg.cpp" line="308"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainFrame</name>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="449"/>
        <source>New Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="452"/>
        <source>Save and close the current project, create a new project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="470"/>
        <source>Close the Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="472"/>
        <source>Save and close the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="455"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="457"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="475"/>
        <source>Insert Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="476"/>
        <source>Insert an existing project in the current project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="482"/>
        <source>Open Foil Design application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="487"/>
        <source>Open XFoil inverse analysis application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="492"/>
        <source>Open XFoil Mixed Inverse analysis application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="497"/>
        <source>Open XFoil direct analysis application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="502"/>
        <source>Open Wing/plane design and analysis application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="460"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3593"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3634"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="462"/>
        <source>Save the project to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="506"/>
        <source>Load Last Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="508"/>
        <source>Loads the last saved project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="465"/>
        <source>Save Project As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="467"/>
        <source>Save the current project under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="515"/>
        <source>Restore toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="516"/>
        <source>Restores the toolbars to their original state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="519"/>
        <source>Save View to Image File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="521"/>
        <source>Saves the current view to a file on disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="536"/>
        <source>Export Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="537"/>
        <source>Export the current graph data to a text file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="542"/>
        <source>Restores the graph&apos;s x and y scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="549"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="551"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="558"/>
        <source>More information about XFLR5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="561"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1407"/>
        <source>Show only associated Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1447"/>
        <source>Save as Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1471"/>
        <source>Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1475"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1480"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2425"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2428"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1476"/>
        <source>Show the properties of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="680"/>
        <source>Define the grid settings for the view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="577"/>
        <source>Store Splines as Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="578"/>
        <source>Store the current splines in the foil database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="581"/>
        <source>Splines Params</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="582"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="586"/>
        <source>Define parameters for the splines : degree, number of out points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="585"/>
        <source>Export Splines To File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="589"/>
        <source>New Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="590"/>
        <source>Reset the splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="708"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2860"/>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="709"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2861"/>
        <source>Zoom the view by drawing a rectangle in the client area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="689"/>
        <source>Reset X Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="690"/>
        <source>Resets the scale to fit the current screen width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="593"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="598"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="603"/>
        <source>Show All Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="605"/>
        <source>Hide All Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="622"/>
        <source>Show Current Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="625"/>
        <source>Hide Current Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="705"/>
        <source>Reset Y Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="693"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="694"/>
        <source>Resets the x and y scales to screen size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="712"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="713"/>
        <source>Zoom Less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="716"/>
        <source>Zoom Y Scale Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="717"/>
        <source>Zoom Y scale Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="628"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2438"/>
        <source>De-rotate the Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="632"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2441"/>
        <source>Normalize the Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="639"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2444"/>
        <source>Refine Locally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="635"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2448"/>
        <source>Refine Globally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="352"/>
        <source>Your system does not provide support for OpenGL.
XFLR5 will not operate correctly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="404"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="404"/>
        <source>Save the project before exit ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="512"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="554"/>
        <source>OpenGL info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="564"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="595"/>
        <source>Cancels the last modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="600"/>
        <source>Restores the last cancelled modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="619"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1443"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2295"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="629"/>
        <source>Set chord line level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="643"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2452"/>
        <source>Edit Foil Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="646"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2455"/>
        <source>Scale camber and thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="649"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2459"/>
        <source>Set T.E. Gap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="652"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2462"/>
        <source>Set L.E. Radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="655"/>
        <source>Show LE Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="658"/>
        <source>Show Legend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="662"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2465"/>
        <source>Set Flap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="665"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2469"/>
        <source>Interpolate Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="668"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2473"/>
        <source>Naca Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="671"/>
        <source>Set Table Columns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="674"/>
        <source>Reset column widths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="679"/>
        <source>Grid Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="698"/>
        <source>Load background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="700"/>
        <source>Clear background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="747"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="789"/>
        <source>F&amp;oil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="787"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1632"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1729"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1810"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1899"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1980"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2065"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2638"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2742"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2900"/>
        <source>Context Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="877"/>
        <source>Foil 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="912"/>
        <source>Inverse foil design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1159"/>
        <source>Display mouse coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1162"/>
        <source>Display the coordinates of the mouse on the top right corner of the graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1175"/>
        <source>Switch to the Operating point view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1182"/>
        <source>Switch to the Polar view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1187"/>
        <source>Time Response View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1189"/>
        <source>Switch to stability analysis post-processing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1202"/>
        <source>Switch to the 3D view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1210"/>
        <source>Switch to the Cp view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1220"/>
        <source>Define which type of polars should be shown or hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1233"/>
        <source>Define the scales for the 3D display of lift, moment, drag, and downwash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1238"/>
        <source>Define the light options in 3D view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1246"/>
        <source>Define (Advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1251"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1387"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1256"/>
        <source>Edit (advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1261"/>
        <source>Edit wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1267"/>
        <source>Edit elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1272"/>
        <source>Edit fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1277"/>
        <source>Edit body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1287"/>
        <source>Rename the currently selected object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1290"/>
        <source>Export to AVL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1291"/>
        <source>Export the current plane or wing to a text file in the format required by AVL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1294"/>
        <source>Export to STL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1299"/>
        <source>Export the current operating point to a text or csv file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1303"/>
        <source>Scale the dimensions of the currently selected wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1306"/>
        <source>Manage objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1307"/>
        <source>Rename or delete the planes and wings stored in the database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1320"/>
        <source>Define the inertia for the current plane or wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1324"/>
        <source>Hide all the curves except for the one corresponding to the currently selected operating point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1329"/>
        <source>Show the graph curves of all operating points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1333"/>
        <source>Hide the graph curves of all operating points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1337"/>
        <source>Delete all the operating points of all planes and polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1341"/>
        <source>Show the curves of all the operating points of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1345"/>
        <source>Hide the curves of all the operating points of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1352"/>
        <source>Delete all the operating points of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1359"/>
        <source>Show XCG location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1360"/>
        <source>Show the position of the center of gravity defined in the analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1365"/>
        <source>Show the graph curves for the elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1370"/>
        <source>Show the graph curves for the fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1375"/>
        <source>Show the graph curves for the second wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1380"/>
        <source>Define an analysis for the current wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1388"/>
        <source>Modify the analysis parameters of this polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1399"/>
        <source>Define a Stability Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1400"/>
        <source>Define a stability analysis for the current wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="545"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1143"/>
        <source>Define Graph Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="480"/>
        <source>Direct Foil Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="485"/>
        <source>XFoil Inverse Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="490"/>
        <source>XFoil Mixed Inverse Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="495"/>
        <source>XFoil Direct Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="500"/>
        <source>Wing and Plane Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="557"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="724"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1503"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2507"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2869"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="772"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="815"/>
        <source>Splines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1040"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1074"/>
        <source>Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1092"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1145"/>
        <source>Define the settings for the selected graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1150"/>
        <source>Reset the scales of all four polar graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1215"/>
        <source>3D View Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1216"/>
        <source>Define the preferences for the 3D view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1223"/>
        <source>Reset scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1224"/>
        <source>Resets the display scale so that the plane fits in the window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1227"/>
        <source>Show flap moments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1229"/>
        <source>Display the flap moment values together with the other operating point results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1295"/>
        <source>Export the current wing to a file in the STL format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1311"/>
        <source>Import Polar(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1312"/>
        <source>Import polar(s) from text file(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1316"/>
        <source>Export polar(s) to text file(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1348"/>
        <source>Show Only Associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1404"/>
        <source>Hide all the polar curves associated to the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1412"/>
        <source>Show all the polar curves associated to the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1416"/>
        <source>Delete all the polars associated to the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1420"/>
        <source>Hide all the polar curves of all wings and planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1424"/>
        <source>Show all the polar curves of all wings and planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1428"/>
        <source>Hide all the operating point curves of the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1432"/>
        <source>Show all the operating point curves of the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1436"/>
        <source>Delete all the operating points of the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1440"/>
        <source>Delete the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1444"/>
        <source>Duplicate the currently selected wing or plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1448"/>
        <source>Save the currently selected wing or plane as a new separate project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1452"/>
        <source>Rename the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1455"/>
        <source>Export results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1456"/>
        <source>Export the currently selected polar to a text or csv file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1460"/>
        <source>Delete all the points of the currently selected polar, but keep the analysis settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1464"/>
        <source>Delete the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1468"/>
        <source>Delete the currently selected operating point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1472"/>
        <source>Define the settings for LLT, VLM and Panel analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1488"/>
        <source>Import plane(s) from xml file(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1491"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2499"/>
        <source>Export analysis to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1494"/>
        <source>Import analysis from xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1495"/>
        <source>Import analysis definition(s) from XML file(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1379"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2339"/>
        <source>Define an Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2344"/>
        <source>Batch Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2520"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2640"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2744"/>
        <source>Current Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2516"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2886"/>
        <source>Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="953"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1232"/>
        <source>3D Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2263"/>
        <source>OpPoint view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2265"/>
        <source>Show Operating point view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2269"/>
        <source>Polar view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2271"/>
        <source>Show Polar view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1219"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2277"/>
        <source>Polar Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1237"/>
        <source>3D Light Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1241"/>
        <source>Define a New Plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1243"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1248"/>
        <source>Shows a dialogbox to create a new plane definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1364"/>
        <source>Show Elevator Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2435"/>
        <source>View Log File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="525"/>
        <source>will revert to default settings at the next session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1481"/>
        <source>Show the properties of the currently selected operating point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="852"/>
        <source>Foil Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="965"/>
        <source>Stability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1173"/>
        <source>OpPoint View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1180"/>
        <source>Polar View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1194"/>
        <source>Root Locus View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1196"/>
        <source>Switch to root locus view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1200"/>
        <source>3D View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1208"/>
        <source>Cp View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1302"/>
        <source>Scale Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1319"/>
        <source>Define Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1323"/>
        <source>Show Current OpPoint Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1328"/>
        <source>Show All OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1332"/>
        <source>Hide All OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1336"/>
        <source>Delete All OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1340"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1431"/>
        <source>Show Associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1344"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1427"/>
        <source>Hide Associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1351"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1435"/>
        <source>Delete Associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1369"/>
        <source>Show Fin Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1374"/>
        <source>Show Second Wing Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1123"/>
        <source>Display the first two graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2280"/>
        <source>Highlight Current OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2282"/>
        <source>Highlights on the polar curve the currently selected operating point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1149"/>
        <source>Reset All Graph Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1154"/>
        <source>All Graph Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1403"/>
        <source>Hide Associated Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1411"/>
        <source>Show Associated Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1415"/>
        <source>Delete Associated Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1419"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2406"/>
        <source>Hide All Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1423"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2403"/>
        <source>Show All Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1566"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1675"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1772"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1854"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1943"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2024"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2108"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2577"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2662"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2766"/>
        <source>Current Polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1598"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1696"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1793"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1874"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2045"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2130"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2611"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2696"/>
        <source>Current OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1716"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1882"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1966"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2782"/>
        <source>Current Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2198"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2239"/>
        <source>Foil 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2301"/>
        <source>Delete associated polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2302"/>
        <source>Delete all the polars associated to this foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2305"/>
        <source>Show only associated polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2309"/>
        <source>Show associated polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2312"/>
        <source>Hide associated polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2318"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2330"/>
        <source>Hide associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2321"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2333"/>
        <source>Show associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2324"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2336"/>
        <source>Delete associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2327"/>
        <source>Export associated OpPoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2341"/>
        <source>Defines a single analysis/polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2346"/>
        <source>Launches a batch of analysis calculation for a specified range or list of Reynolds numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2349"/>
        <source>Multi-threaded Batch Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2351"/>
        <source>Launches a batch of analysis calculation using all available computer CPU cores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="609"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1439"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1463"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1467"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2285"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2354"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2422"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2355"/>
        <source>Deletes the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1459"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2358"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2359"/>
        <source>Deletes the contents of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2363"/>
        <source>Remove the unconverged or erroneaous points of the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="616"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1298"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2292"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2366"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2419"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1315"/>
        <source>Export all polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2375"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2819"/>
        <source>Define Styles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2376"/>
        <source>Define the style for the boundary layer and the pressure arrows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2388"/>
        <source>Manage Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="612"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1286"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1451"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2288"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2392"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2385"/>
        <source>Reset Foil Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2386"/>
        <source>Resets the foil&apos;s scale to original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2397"/>
        <source>Show Inviscid Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2399"/>
        <source>Display the Opp&apos;s inviscid curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2378"/>
        <source>Neutral Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2298"/>
        <source>Set Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2315"/>
        <source>Export polars to .plr file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2369"/>
        <source>to text format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2372"/>
        <source>to .plr format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2409"/>
        <source>Show Current Opp Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2413"/>
        <source>Show All Opps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2416"/>
        <source>Hide All Opps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2431"/>
        <source>XFoil Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2432"/>
        <source>Tip : you don&apos;t want to use that option...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2476"/>
        <source>Cp Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2478"/>
        <source>Sets Cp vs. chord graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2481"/>
        <source>Q Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2483"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2487"/>
        <source>Sets Speed vs. chord graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2596"/>
        <source>Export all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2609"/>
        <source>Operating Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2619"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2707"/>
        <source>Cp Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2811"/>
        <source>Store Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2812"/>
        <source>Store Foil in database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2815"/>
        <source>Extract Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2816"/>
        <source>Extract a Foil from the database for modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2820"/>
        <source>Define the styles for this view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2831"/>
        <source>Resets the scale to fit the screen size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="683"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2834"/>
        <source>Insert Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="686"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2837"/>
        <source>Remove Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="908"/>
        <source>Direct foil analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="916"/>
        <source>Plane analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="920"/>
        <source>Foil direct design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1064"/>
        <source>O&amp;ptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1113"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2879"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1129"/>
        <source>Four Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1131"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1138"/>
        <source>Display four graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1155"/>
        <source>Define the settings of all graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1252"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1257"/>
        <source>Shows a form to edit the currently selected plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1485"/>
        <source>Export to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1262"/>
        <source>Shows a form to edit the wing of the currently selected plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1278"/>
        <source>Shows a form to edit the body of the currently selected plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1282"/>
        <source>Edit body (advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1355"/>
        <source>Show Target Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1383"/>
        <source>Define an Analysis (advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1384"/>
        <source>Shows a form to edit a new polar object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1391"/>
        <source>Edit object (advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1392"/>
        <source>Shows a form to edit the currently selected polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1396"/>
        <source>Modify the data points of this polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1522"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1634"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1731"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1812"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1901"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1982"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2067"/>
        <source>Current Plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1517"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2176"/>
        <source>Plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1395"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2362"/>
        <source>Edit data points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2486"/>
        <source>Export BL Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2493"/>
        <source>Import XFoil Polar(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2496"/>
        <source>Import Analysis from xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2823"/>
        <source>Overlay foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2824"/>
        <source>Overlay an additional foil for guidance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2827"/>
        <source>Clear overlay foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2840"/>
        <source>Show Q-Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2844"/>
        <source>Show Q-Spec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2848"/>
        <source>Show Q-Viscous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2852"/>
        <source>Show Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2856"/>
        <source>Show Reflected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2934"/>
        <source>Full Inverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2935"/>
        <source>Mixed Inverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2939"/>
        <source>XInverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3910"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3743"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3518"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3592"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3633"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3910"/>
        <source>Save the current project ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3733"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3819"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="352"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="360"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3616"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3656"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3743"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3756"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3765"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4269"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4336"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4528"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4613"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4647"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4672"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4688"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5356"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5395"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5420"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5441"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5456"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5470"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3922"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4048"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4079"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4092"/>
        <source>The project </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3922"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4048"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4079"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4092"/>
        <source> has been saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3953"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3957"/>
        <source>Default Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="524"/>
        <source>Reset Default Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="540"/>
        <source>Reset Graph Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1121"/>
        <source>Two Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1136"/>
        <source>All Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1524"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1619"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1636"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1733"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1814"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1903"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1984"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2069"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2563"/>
        <source>Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1564"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2575"/>
        <source>Polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="1596"/>
        <source>OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2547"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2678"/>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="2830"/>
        <source>Reset foil scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3517"/>
        <source>Could not open the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3616"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3656"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3756"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3765"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5356"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5395"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5420"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5441"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5456"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5470"/>
        <source>Error reading the file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3616"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3656"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5356"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5395"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5420"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5441"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5456"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="5470"/>
        <source>Saved the valid part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3953"/>
        <source>Are you sure you want to reset the default settings ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3957"/>
        <source>The settings will be reset at the next session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4174"/>
        <source>Set a transparent background ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4620"/>
        <source>Error saving the project file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4624"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4647"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4688"/>
        <source>Nothing to save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4583"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4655"/>
        <source>Save the Project File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4613"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4672"/>
        <source>Could not open the file for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4124"/>
        <source>Save Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4269"/>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4336"/>
        <source>Unidentified Operating Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="4528"/>
        <source>Obsolete format, cannot read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="6208"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManageFoilsDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="39"/>
        <source>Foil Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="121"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="122"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="123"/>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="305"/>
        <source>Export Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="125"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="164"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="165"/>
        <source>Thickness (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="166"/>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="168"/>
        <source>at (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="167"/>
        <source>Camber (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="169"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="170"/>
        <source>TE Flap (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="171"/>
        <source>TE XHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="172"/>
        <source>TE YHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="173"/>
        <source>LE Flap (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="174"/>
        <source>LE XHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="175"/>
        <source>LE YHinge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="178"/>
        <source>Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="284"/>
        <source>Enter the foil&apos;s new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/mgt/managefoilsdlg.cpp" line="307"/>
        <source>Foil File (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManagePlanesDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="41"/>
        <source>Plane Object Management</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="83"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="84"/>
        <source>Span</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="85"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="86"/>
        <source>M.A.C.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="87"/>
        <source>AR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="88"/>
        <source>TR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="89"/>
        <source>Rt-Tip Sweep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="91"/>
        <source>Tail Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="185"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="186"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="207"/>
        <source>Planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="176"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="300"/>
        <source>Are you sure you want to delete the plane :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/manageplanesdlg.cpp" line="302"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Miarex</name>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="284"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="285"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7108"/>
        <source>Cp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="337"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="352"/>
        <source>Real</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="338"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="353"/>
        <source>Imag/2.pi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="377"/>
        <source>Cp Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="713"/>
        <source>Cp Curves are only available for VLM and panel methods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1406"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1545"/>
        <source>Induced Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1416"/>
        <source>Total Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1425"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1434"/>
        <source>Local lift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1443"/>
        <source>Airfoil drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1452"/>
        <source>Induced drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1461"/>
        <source>Total drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1470"/>
        <source>Local drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1479"/>
        <source>Cm Airfoil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1488"/>
        <source>Cm total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1497"/>
        <source>Re</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1506"/>
        <source>Top Trans x-Pos %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1515"/>
        <source>Bot Trans x-Pos %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1524"/>
        <source>CP x-Pos %</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="1536"/>
        <source>BM (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2224"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2229"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2282"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2289"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4388"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5000"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5020"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7641"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7646"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7663"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7684"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8579"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8656"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8711"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2224"/>
        <source>Please define a plane object before running a calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2229"/>
        <source>Please define an analysis/polar before running a calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2281"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2288"/>
        <source>Could not find the wing&apos;s foil </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2281"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="2288"/>
        <source>...
Aborting Calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3204"/>
        <source>Are you sure you want to delete the plane :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3205"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3309"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3331"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5465"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3308"/>
        <source>Are you sure you want to delete the polars associated to :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3330"/>
        <source>Are you sure you want to delete the polar :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3434"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3541"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3632"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3740"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3856"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="3961"/>
        <source>The modification will erase all results associated to this Plane.
Continue ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4032"/>
        <source>Export OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4034"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4325"/>
        <source>Text File (*.txt);;Comma Separated Values (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4087"/>
        <source>Cd    = %1     ICd   = %2     PCd   = %3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4091"/>
        <source>Cd=,%1,ICd=, %2,PCd=, %3
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4097"/>
        <source>Cl   = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4099"/>
        <source>Cm   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4102"/>
        <source>ICn   = %1     PCn   = %2 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4103"/>
        <source>ICn=, %1,PCn=, %2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4115"/>
        <source>Bending =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4221"/>
        <source>Flap </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4234"/>
        <source>Main Wing Cp Coefficients
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4235"/>
        <source>Wing Cp Coefficients
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4242"/>
        <source> Panel     CtrlPt.x        CtrlPt.y        CtrlPt.z       Nx      Ny       Nz        Area       Cp
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4243"/>
        <source>Panel,CtrlPt.x,CtrlPt.y,CtrlPt.z,Nx,Ny,Nz,Area,Cp
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4253"/>
        <source>Cp Coefficients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4263"/>
        <source>Strip %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4323"/>
        <source>Export Polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4365"/>
        <source>Export Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4387"/>
        <source>Could not write to the directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4408"/>
        <source>Export Plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4410"/>
        <source>AVL Text File (*.avl)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4434"/>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4985"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4987"/>
        <source>Plane Polar Format (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="4999"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8578"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8655"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8710"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5017"/>
        <source>No Plane with the name </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5018"/>
        <source>
could be found. The polar(s) will not be stored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5464"/>
        <source>Are you sure you want to reset the content of the polar :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6011"/>
        <source>The modification will erase all polar results associated to this Plane.
Continue ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6188"/>
        <source>Wing Span      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6193"/>
        <source>xyProj. Span   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6198"/>
        <source>Wing Area      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6203"/>
        <source>xyProj. Area   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6209"/>
        <source>Plane Mass     =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6215"/>
        <source>Wing Load      =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6222"/>
        <source>Tail Volume    =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6227"/>
        <source>Root Chord     =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6232"/>
        <source>MAC            =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6237"/>
        <source>TipTwist       =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6241"/>
        <source>Aspect Ratio   =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6245"/>
        <source>Taper Ratio    =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6249"/>
        <source>Root-Tip Sweep =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6257"/>
        <source>XNP = d(XCp.Cl)/dCl =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6263"/>
        <source>Mesh elements  =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="6319"/>
        <source>Point is out of the flight envelope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7040"/>
        <source>Analysis settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7044"/>
        <source>Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7048"/>
        <source>Start=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7049"/>
        <source>End=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7050"/>
        <source>D=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7079"/>
        <source>Init LLT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7080"/>
        <source>Store OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7085"/>
        <source>Analyze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7096"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7101"/>
        <source>Display the force 1/2.rho.V2.S.Cp acting on the panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7102"/>
        <source>Lift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7103"/>
        <source>Ind. Drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7104"/>
        <source>Visc. Drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7105"/>
        <source>Trans.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7106"/>
        <source>Moment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7107"/>
        <source>Downwash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7109"/>
        <source>Surf. Vel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7110"/>
        <source>Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7111"/>
        <source>Animate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7141"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7896"/>
        <source>Polar properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7154"/>
        <source>Curve settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7158"/>
        <source>Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7159"/>
        <source>Flow down style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7160"/>
        <source>If activated:
all changes made to the style of the polar objects will flow down to the operating points
all changes made to the style of the foil objects will flow down to the polars and to the operating points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7178"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7179"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7180"/>
        <source>item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7192"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7193"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7194"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7195"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7219"/>
        <source>Cp Sections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7232"/>
        <source>Span Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7239"/>
        <source>Keep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7240"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7253"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7259"/>
        <source>Axes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7261"/>
        <source>Surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7262"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7263"/>
        <source>Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7264"/>
        <source>Foil Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7265"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7293"/>
        <source>X View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7294"/>
        <source>Y View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7295"/>
        <source>Z View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7296"/>
        <source>Iso View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7297"/>
        <source>Flip View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7317"/>
        <source>Reset scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7318"/>
        <source>Resets the display scale so that the plane fits in the window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7324"/>
        <source>Clip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7641"/>
        <source>Cannot (yet ?) save 8 bit depth opengl screen images... Sorry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7646"/>
        <source>Cannot (yet ?) save 16 bit depth opengl screen images... Sorry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7663"/>
        <source>Unidentified bit depth... Sorry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="7911"/>
        <source>Operating point Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8426"/>
        <source>Export to STL File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8428"/>
        <source>STL File (*.stl)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8568"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8612"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8633"/>
        <source>Open XML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8570"/>
        <source>XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8614"/>
        <source>Plane XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8635"/>
        <source>Analysis XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8675"/>
        <source>Attaching the analysis to the active plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8681"/>
        <source>No plane to attach the polar to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8753"/>
        <source>Export plane definition to xml file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8790"/>
        <source>Export analysis definition to xml file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/moddlg.cpp" line="29"/>
        <source>Modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/moddlg.cpp" line="46"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/moddlg.cpp" line="47"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/moddlg.cpp" line="48"/>
        <source>Save as new</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NacaFoilDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="37"/>
        <source>NACA Foils</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="61"/>
        <source>4 or 5 digits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="62"/>
        <source>Number of Panels:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="70"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="72"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="135"/>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="142"/>
        <location filename="../xflr5-gui/xdirect/geometry/nacafoildlg.cpp" line="149"/>
        <source>Illegal NACA Number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewNameDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/newnamedlg.cpp" line="46"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/newnamedlg.cpp" line="48"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectPropsDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/objectpropsdlg.cpp" line="46"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OpPointWidget</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="586"/>
        <source>Thickness         = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="590"/>
        <source>Max. Thick.pos.   = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="594"/>
        <source>Max. Camber       = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="598"/>
        <source>Max. Camber pos.  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="602"/>
        <source>Number of Panels  =  %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="608"/>
        <source>Flap Angle = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="612"/>
        <source>XHinge     = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="617"/>
        <source>YHinge     = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="636"/>
        <source>TE Hinge Moment/span = 0123456789</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="645"/>
        <source>Fixed speed polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="646"/>
        <source>Fixed lift polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="647"/>
        <source>Rubber chord polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="648"/>
        <source>Fixed a.o.a. polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="665"/>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="676"/>
        <source>Re.sqrt(Cl) = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="669"/>
        <source>M.sqrt(Cl) = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="698"/>
        <source>Forced Upper Trans. = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="701"/>
        <source>Forced Lower Trans. = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="722"/>
        <source>Alpha = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="726"/>
        <source>Cl = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="730"/>
        <source>Cm = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="734"/>
        <source>Cd = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="740"/>
        <source>L/D = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="745"/>
        <source>Upper Trans. = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="749"/>
        <source>Lower Trans. = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="755"/>
        <source>TE Hinge Moment/span = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/oppointwidget.cpp" line="762"/>
        <source>LE Hinge Moment/span = %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PanelAnalysisDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="59"/>
        <source>3D Panel Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="160"/>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="213"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="163"/>
        <source>Keep this window opened on errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="288"/>
        <source>Panel Analysis completed successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="290"/>
        <source>Panel Analysis completed ... Errors encountered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/panelanalysisdlg.cpp" line="315"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PertDlg</name>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="35"/>
        <source>Pertubation Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="94"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="95"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="96"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="97"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/pertdlg.cpp" line="79"/>
        <source>Cn List</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlaneDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="53"/>
        <source>Plane Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="477"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="604"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="730"/>
        <source>Save the changes ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="453"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="731"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="840"/>
        <source>Plane Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="842"/>
        <source>Enter here a short description for the plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="843"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="844"/>
        <source>Plane Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="836"/>
        <source>Plane Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="861"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="897"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="931"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="965"/>
        <source>Define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="862"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="898"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="863"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="899"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="932"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="968"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1047"/>
        <source>x=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="864"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="900"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="933"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="970"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1048"/>
        <source>z=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="865"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="901"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="934"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="971"/>
        <source>Tilt Angle=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="853"/>
        <source>Main Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="895"/>
        <source>Biplane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="891"/>
        <source>Wing 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="452"/>
        <source>Revert to the default body definition ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="466"/>
        <source>Open XML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="468"/>
        <source>Plane XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="476"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="857"/>
        <source>Main wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="926"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="930"/>
        <source>Elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="960"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="964"/>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="966"/>
        <source>Double Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="967"/>
        <source>Two-sided Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="969"/>
        <source>y=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1004"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1008"/>
        <source>Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1010"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1013"/>
        <source>Define (Advanced users)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1016"/>
        <source>Reset default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1019"/>
        <source>Import body definition from an XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1022"/>
        <source>Import body definition from another plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1026"/>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1028"/>
        <source>Actions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1060"/>
        <source>Warning:
Including the body in the analysis is not recommended.
Check the guidelines for explanations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1071"/>
        <source>Wing Area = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1072"/>
        <source>Wing Span = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1073"/>
        <source>Elev. Area = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1074"/>
        <source>Elev. Lever Arm = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1113"/>
        <source>Fin Area = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1114"/>
        <source>TailVolume = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/planedlg.cpp" line="1115"/>
        <source>Total Panels = </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PolarFilterDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="31"/>
        <source>Polar Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="44"/>
        <source>Show polar types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="46"/>
        <source>Type 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="46"/>
        <source>fixed speed polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="47"/>
        <source>Type 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="47"/>
        <source>fixed lift polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="48"/>
        <source>Type 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="48"/>
        <source>XFoil rubber chord polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="49"/>
        <source>Type 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="49"/>
        <source>fixed a.o.a. polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="50"/>
        <source>Type 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/polarfilterdlg.cpp" line="50"/>
        <source>stability polars</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="44"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="93"/>
        <source>Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="94"/>
        <source>Save options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="95"/>
        <source>Display options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="96"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/preferencesdlg.cpp" line="97"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgressDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/progressdlg.cpp" line="54"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/progressdlg.cpp" line="62"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="500"/>
        <source>dihedral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="501"/>
        <source>twist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="502"/>
        <source>foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="503"/>
        <source>X-panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="504"/>
        <source>X-dist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="505"/>
        <source>Y-panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="506"/>
        <source>Y-dist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dwingdlg.cpp" line="1304"/>
        <source>Wing definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="82"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/foilcoorddlg.cpp" line="83"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="212"/>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="72"/>
        <source>Re</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="218"/>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="73"/>
        <source>Mach</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="224"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="824"/>
        <source>CL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="227"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="826"/>
        <source>CD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="230"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="840"/>
        <source>Cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="233"/>
        <source>Cdp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="236"/>
        <source>Cpmn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="239"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="816"/>
        <source>XCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="242"/>
        <source>Top Transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="245"/>
        <source>Bot Transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="250"/>
        <source>T.E. Flap moment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="255"/>
        <source>L.E. Flap moment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="780"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="782"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="775"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8836"/>
        <source>Fixed speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="783"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="776"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8837"/>
        <source>Fixed lift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="784"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="777"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8838"/>
        <source>Fixed angle of attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="789"/>
        <source>Reynolds number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="791"/>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="805"/>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="812"/>
        <source>Mach number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="803"/>
        <source>Re.Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="820"/>
        <source>Forced top trans.   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="215"/>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="810"/>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="797"/>
        <source>Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/opppoint.cpp" line="221"/>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="817"/>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="74"/>
        <source>NCrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="823"/>
        <source>Forced bottom trans.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects2d/polar.cpp" line="826"/>
        <source>Number of data points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="157"/>
        <source>Re List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="847"/>
        <source>Cn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="33"/>
        <source>Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="37"/>
        <source>2nd Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="41"/>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="453"/>
        <source>Elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="58"/>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="454"/>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="103"/>
        <source>Plane Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="451"/>
        <source>Main Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/plane.cpp" line="452"/>
        <source>Second Wing2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/gui_objects/splinefoil.cpp" line="82"/>
        <location filename="../xflr5-gui/gui_objects/splinefoil.cpp" line="230"/>
        <source>Spline Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/body.cpp" line="34"/>
        <source>Body Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="525"/>
        <source>Export Body Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="527"/>
        <source>Text Format (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1320"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="557"/>
        <source>Export Body Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="6939"/>
        <source>Export Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="6940"/>
        <location filename="../xflr5-gui/miarex/design/editbodydlg.cpp" line="1322"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="559"/>
        <source>Text File (*.txt);;Comma Separated Values (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="587"/>
        <source>Choose the length unit to read this file :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="598"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="600"/>
        <source>All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="608"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3836"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="609"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="617"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="870"/>
        <location filename="../xflr5-gui/miarex/design/gl3dbodydlg.cpp" line="896"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/mainframe.cpp" line="3836"/>
        <source>Multiple file loading only available for airfoil files.
Non *.dat files will be ignored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/body.cpp" line="1926"/>
        <source>Error reading </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/body.cpp" line="1926"/>
        <source>
Frames have different number of side points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="779"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8839"/>
        <source>Stability analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8845"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8857"/>
        <source>VInf =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8850"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8855"/>
        <source>Alpha =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="778"/>
        <source>Beta range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="783"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8868"/>
        <source>LLT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="784"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8869"/>
        <source>3D-Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="785"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8870"/>
        <source>3D-Panels/VLM1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="786"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8871"/>
        <source>3D-Panels/VLM2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="794"/>
        <source>VInf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="800"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8991"/>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="811"/>
        <source>Control value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="813"/>
        <source>XNP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="818"/>
        <source>YCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="820"/>
        <source>ZCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="828"/>
        <source>VCD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="830"/>
        <source>ICD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="832"/>
        <source>CX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="834"/>
        <source>CY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="837"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="842"/>
        <source>ICm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="844"/>
        <source>VCm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="849"/>
        <source>ICn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="851"/>
        <source>VCn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="869"/>
        <source>Non-dimensional Stability Derivatives:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="870"/>
        <source>CXu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="872"/>
        <source>CLu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="874"/>
        <source>Cmu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="876"/>
        <source>CXa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="878"/>
        <source>CLa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="880"/>
        <source>Cma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="882"/>
        <source>CXq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="884"/>
        <source>CLq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="886"/>
        <source>Cmq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="888"/>
        <source>CYb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="890"/>
        <source>Clb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="892"/>
        <source>Cnb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="894"/>
        <source>CYp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="896"/>
        <source>Clp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="898"/>
        <source>Cnp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="900"/>
        <source>CYr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="902"/>
        <source>Clr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="904"/>
        <source>Cnr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="910"/>
        <source>Non-dimensional Control Derivatives:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="911"/>
        <source>CXd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="913"/>
        <source>CYd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="915"/>
        <source>CZd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="917"/>
        <source>Cld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="919"/>
        <source>Cmd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="921"/>
        <source>Cnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8840"/>
        <source>Sideslip analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9001"/>
        <source>CoG.x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9012"/>
        <source>CoG.z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9068"/>
        <source>B.C. = Dirichlet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9069"/>
        <source>B.C. = Neumann</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9073"/>
        <source>Analysis type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9074"/>
        <source>Viscous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9075"/>
        <source>Inviscid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9079"/>
        <source>Body panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9080"/>
        <source>ignored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9081"/>
        <source>included</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9088"/>
        <source>Ref. area  =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9089"/>
        <source>Ref. span  =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9090"/>
        <source>Ref. chord =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9085"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9086"/>
        <source>Ref. dimensions = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9085"/>
        <source>Planform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9086"/>
        <source>Projected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9108"/>
        <source>Data points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="805"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="8863"/>
        <source>Beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/planeopp.cpp" line="790"/>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9093"/>
        <source>Tilted geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9097"/>
        <source>Ground height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9101"/>
        <source>Density =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="9104"/>
        <source>Viscosity =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/wing.cpp" line="82"/>
        <source>Wing Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/wing.cpp" line="1875"/>
        <location filename="../xflr5-engine/objects/objects3d/wing.cpp" line="1888"/>
        <source>           Span pos = %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/wing.cpp" line="1881"/>
        <source>,  Cl = %1 could not be interpolated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/wing.cpp" line="1893"/>
        <source>,  Cl = %1 is outside the flight envelope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="80"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="97"/>
        <source>Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="81"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="98"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="82"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="99"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="163"/>
        <source>Upper side points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="193"/>
        <source>Lower side points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="247"/>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="263"/>
        <source>Invalid Analysis Settings
CpCalc: local speed too large
 Compressibility corrections invalid </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="259"/>
        <source>Cl = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="279"/>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="377"/>
        <source>   ...converged after %1 iterations
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="284"/>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiltask.cpp" line="382"/>
        <source>   ...unconverged after %1 iterations
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-engine/objects/objects3d/surface.cpp" line="885"/>
        <source>Continuous foils for surface do not have the same initial flap angle... aborting
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/miarex.cpp" line="5351"/>
        <location filename="../xflr5-gui/miarex/objects3d.cpp" line="719"/>
        <source>Enter the new name for the Polar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/objects3d.cpp" line="551"/>
        <source>Enter the new name for the Plane :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/xmlplanereader.cpp" line="85"/>
        <source>The file is not an xflr5 plane version 1.0 file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="255"/>
        <source>Text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/mgt/xmlwpolarreader.cpp" line="84"/>
        <location filename="../xflr5-gui/xdirect/xml/xmlpolarreader.cpp" line="53"/>
        <source>The file is not an xflr5 polar version 1.0 file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/script/xflscriptreader.cpp" line="55"/>
        <source>The file is not an xflr5 readable script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="150"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="151"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="152"/>
        <source>Save All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="153"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="154"/>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="155"/>
        <source>Yes to &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="156"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="157"/>
        <source>N&amp;o to All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="158"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="159"/>
        <source>Retry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="160"/>
        <source>Ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="161"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="162"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="163"/>
        <source>Discard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="164"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="165"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="166"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/globals/xflr5application.cpp" line="167"/>
        <source>Restore Defaults</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReListDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="34"/>
        <source>Reynolds Number List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="136"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="137"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="139"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/relistdlg.cpp" line="140"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RenameDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="29"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="58"/>
        <source>Note : Overwrite will delete operating points and reset polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="62"/>
        <source>Existing Names:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="49"/>
        <source>Overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="104"/>
        <source>Enter a name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="166"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="166"/>
        <source>Must enter a name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="180"/>
        <source>Do you wish to overwrite </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/renamedlg.cpp" line="181"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>STLExportDlg</name>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="40"/>
        <source>STL exporter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="54"/>
        <source>File format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="58"/>
        <source>Binary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="59"/>
        <source>ASCII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="66"/>
        <source>Object to export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="70"/>
        <source>Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="71"/>
        <source>Main Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="72"/>
        <source>Second Wing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="73"/>
        <source>Elevator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="74"/>
        <source>Fin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="84"/>
        <source>Output Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="208"/>
        <source>Number of x-panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="209"/>
        <source>Number of hoop/y panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="213"/>
        <source>Number of chordwise panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/stlexportdialog.cpp" line="214"/>
        <source>Number of span panels per surface</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptions</name>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="46"/>
        <source>Load options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="50"/>
        <source>Load last project on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="55"/>
        <source>Operating point save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="59"/>
        <source>Save:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="60"/>
        <source>Foil Operating Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="61"/>
        <source>Wing and Plane Operating Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="69"/>
        <source>Autosave setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/saveoptions.cpp" line="74"/>
        <source>Every</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Section2dWidget</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="101"/>
        <source>Insert Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="105"/>
        <source>Remove Control Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="113"/>
        <source>Reset Scales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="117"/>
        <source>Grid Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="125"/>
        <source>Load background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="129"/>
        <source>Clear background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="179"/>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="1024"/>
        <source>X-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="180"/>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="1025"/>
        <source>Y-Scale = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="181"/>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="1026"/>
        <source>x  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="182"/>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="1027"/>
        <source>y  = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/section2dwidget.cpp" line="256"/>
        <source>Open Image File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="65"/>
        <source>General Display Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="142"/>
        <source>Widget Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="149"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="155"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="156"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="157"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="166"/>
        <source>Background Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="197"/>
        <source>Graph Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="201"/>
        <source>All Graph Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="220"/>
        <source>Flow down changes made to the style of objects to their children</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="221"/>
        <source>If activated:
all changes made to the style of the polar objects will flow down to the operating points
all changes made to the style of the foil objects will flow down to the polars and to the operating points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="176"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="180"/>
        <source>Main display font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="188"/>
        <source>Table font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/settings.cpp" line="219"/>
        <source>Reverse zoom direction using mouse wheel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SplineCtrlsDlg</name>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="42"/>
        <source>Spline Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="143"/>
        <source>Upper side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="174"/>
        <source>Lower side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="149"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="180"/>
        <source>Spline degree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="150"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="181"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="223"/>
        <source>Symetric foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="213"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="214"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="226"/>
        <source>Force closed LE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="227"/>
        <source>Force closed TE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="312"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="326"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="312"/>
        <location filename="../xflr5-gui/design/splinectrlsdlg.cpp" line="326"/>
        <source>The spline degree must be less than the number of control points</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StabPolarDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="47"/>
        <source>Stability Polar Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="997"/>
        <source>Control Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="948"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="987"/>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="157"/>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="166"/>
        <source>CoG_x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="175"/>
        <source>CoG_z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="184"/>
        <source>Ixx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="193"/>
        <source>Iyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="202"/>
        <source>Izz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="211"/>
        <source>Ixz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="256"/>
        <source>Wing Tilt (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="266"/>
        <source>Elevator Tilt </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="293"/>
        <source>Elevator Flap %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="306"/>
        <source>Fin Flap %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="589"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="598"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="589"/>
        <source>Mass must be non-zero for type 7 polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="896"/>
        <source>Ref. area=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="897"/>
        <source>Ref. span length=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="898"/>
        <source>Ref. chord length=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1081"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1090"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1121"/>
        <source>Extra drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1091"/>
        <source>Extra area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1092"/>
        <source>Extra drag coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1134"/>
        <source>Auto Analysis Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1135"/>
        <source>Polar Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="854"/>
        <source>b =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="279"/>
        <source>Wing Flap %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="598"/>
        <source>Must enter a name for the polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="806"/>
        <source>Analysis methods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="810"/>
        <source>Ring vortex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="823"/>
        <source>Mix 3D Panels/VLM2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="842"/>
        <source>Note : the analysis may be of the viscous type only if all the flap controls are inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="850"/>
        <source>Flight attitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="855"/>
        <source>f =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="886"/>
        <source>Ref. dimensions for aero coefficients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="890"/>
        <source>Wing Planform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="891"/>
        <source>Wing Planform projected on xy plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="892"/>
        <source>Manual input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="943"/>
        <source>Use plane inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="811"/>
        <source>3D Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1014"/>
        <source>Note: + sign means trailing edge down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="960"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="998"/>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="841"/>
        <source>Viscous Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="961"/>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1029"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1031"/>
        <source>International</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1032"/>
        <source>Imperial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="819"/>
        <source>Plane analysis methods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="824"/>
        <source>Ignore Body Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="958"/>
        <source>Inertia parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="959"/>
        <source>Mean value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1023"/>
        <source>Air Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1066"/>
        <source>From Altitude and Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1116"/>
        <source>Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1117"/>
        <source>Ref. dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1118"/>
        <source>Mass and inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1119"/>
        <source>Control parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/stabpolardlg.cpp" line="1120"/>
        <source>Aero data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StabViewDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="54"/>
        <source>Stability View Params</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="594"/>
        <source>Longitudinal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="595"/>
        <source>Lateral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="592"/>
        <source>Stability direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="614"/>
        <source>Initial Conditions Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="616"/>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="657"/>
        <source>Forced Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="624"/>
        <source>Initial conditions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="612"/>
        <source>Modal Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="684"/>
        <source>Modal response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="708"/>
        <source>Define the total time range for the graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="710"/>
        <source>Define the time step for the resolution of the differential equations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="729"/>
        <source>Re-calculate the currently selected curve with the user-specified input data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="731"/>
        <source>Add a new curve to the graphs, using the current user-specified input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="733"/>
        <source>Rename the currently selected curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="735"/>
        <source>Delete the currently selected curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="608"/>
        <source>Time Graph Params</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="769"/>
        <source>Mode Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="861"/>
        <source>Eigenvalues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="790"/>
        <source>Mode properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="162"/>
        <source>&lt;small&gt;Mode Properties:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="715"/>
        <source>Total Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="767"/>
        <source>Operating point modes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="906"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="920"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="935"/>
        <source>Animate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="937"/>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="945"/>
        <source>Time Step =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="946"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="902"/>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="113"/>
        <source>Time (s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="114"/>
        <source>Angle </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="119"/>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="660"/>
        <source>Control function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="664"/>
        <source>Enter the function of the control vs. time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="743"/>
        <source>Curve Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="728"/>
        <source>Recalc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="730"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="732"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="734"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="777"/>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="778"/>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="779"/>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="780"/>
        <source>Press Ctrl+H to highlight the mode on the root locus plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="812"/>
        <source>Natural frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="816"/>
        <source>Damped natural frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="820"/>
        <source>Damping ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="824"/>
        <source>Time to double</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="828"/>
        <source>Time constant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1032"/>
        <source>u0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1033"/>
        <source>w0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1034"/>
        <source>q0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1041"/>
        <source>v0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1042"/>
        <source>p0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1043"/>
        <source>r0=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/stabviewdlg.cpp" line="1221"/>
        <source>New curve</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TEGapDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="36"/>
        <source>T.E. Gap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="59"/>
        <source>T.E. Gap Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="62"/>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="74"/>
        <source>% chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="71"/>
        <source>Blending Distance from T.E.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="83"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="84"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="85"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="198"/>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="207"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="198"/>
        <source>Unrecognized foil format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/tegapdlg.cpp" line="207"/>
        <source>Panel number cannot exceed 300</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TargetCurveDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="60"/>
        <source>Show Elliptic Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="67"/>
        <source>Show Bell Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="73"/>
        <source>Bell Curve exponent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="78"/>
        <source>Cl Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="82"/>
        <source>Max local Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="83"/>
        <source>Wing CL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/targetcurvedlg.cpp" line="96"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TwoDPanelDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="51"/>
        <source>Global Panel Refinement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="54"/>
        <source>Number of Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="55"/>
        <source>Panel Bunching Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="56"/>
        <source>TE/LE Panel Density Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="57"/>
        <source>Refined area/LE Panel Density Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="58"/>
        <source>Top Side Refined Area x/c limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="59"/>
        <source>Bottom Side Refined Area x/c limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="215"/>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="226"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="215"/>
        <source>Unrecognized foil format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/geometry/twodpaneldlg.cpp" line="225"/>
        <source>The total number of panels cannot exceed %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Units</name>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="50"/>
        <source>Select the units for this project :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="51"/>
        <source>Units Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="62"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="63"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="64"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="65"/>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="66"/>
        <source>Force</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="67"/>
        <source>Moment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="68"/>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="69"/>
        <source>Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/misc/options/units.cpp" line="95"/>
        <source>Define the project units</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>View3dTestDlg</name>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="113"/>
        <source>Context &amp;version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="125"/>
        <source>Create context</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="137"/>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="154"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="281"/>
        <source>   OpenGL version: %1.%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/glcontextinfo/view3dtestdlg.cpp" line="285"/>
        <source>   Profile: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>W3dPrefsDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="94"/>
        <source>3D Styles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="144"/>
        <source>Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="145"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="146"/>
        <source>VLM Mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="147"/>
        <source>Top transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="148"/>
        <source>Bottom transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="149"/>
        <source>Lift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="150"/>
        <source>Moments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="151"/>
        <source>Induced Drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="152"/>
        <source>Viscous Drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="153"/>
        <source>Downwash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="154"/>
        <source>WakePanels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="155"/>
        <source>Streamlines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="156"/>
        <source>Masses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="186"/>
        <source>Color settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="225"/>
        <source>Tessellation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="237"/>
        <source>Increase the number of points to improve the resolution
of the surfaces.This may reduce the display speed.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="239"/>
        <source>Wing chordwise direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="241"/>
        <source>Body axial direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="243"/>
        <source>Body hoop direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="272"/>
        <source>Animate view transitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="273"/>
        <source>Auto Adjust 3D scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="274"/>
        <source>Automatically adjust the 3D scale to fit the plane in the display when switching between planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="275"/>
        <source>Enable clip plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="279"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/view/w3dprefsdlg.cpp" line="281"/>
        <source>Reset Defaults</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WAdvancedDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="39"/>
        <source>Wing Analysis Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="79"/>
        <source>View Log File after errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="80"/>
        <source>Store points outside the polar mesh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="75"/>
        <source>All Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="87"/>
        <source>VLM and Panel Methods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="109"/>
        <source>Core Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="122"/>
        <source>VLM Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="128"/>
        <source>Vortex Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="129"/>
        <source>Control Point Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="146"/>
        <source>Lifting Line Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="155"/>
        <source>Relax. factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="156"/>
        <source>Alpha Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="157"/>
        <source>Max. Iterations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="154"/>
        <source>Number of spanwise stations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="95"/>
        <source>Ignore wing panels with span width &lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wadvanceddlg.cpp" line="174"/>
        <source>3D Panel boundary conditions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WPolarDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="48"/>
        <source>Analysis Definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="527"/>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="535"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="527"/>
        <source>Must enter a name for the polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1085"/>
        <source>Auto Analysis Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1086"/>
        <source>Polar Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="727"/>
        <source>Type 1 (Fixed Speed)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="728"/>
        <source>Type 2 (Fixed Lift)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="729"/>
        <source>Type 4 (Fixed aoa)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1066"/>
        <source>Polar Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="740"/>
        <source>Free Stream Speed =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="730"/>
        <source>Type 5 (Beta range)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="800"/>
        <source>Analysis Methods</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="804"/>
        <source>LLT (Wing only)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="805"/>
        <source>Horseshoe vortex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="805"/>
        <source>(No sideslip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="806"/>
        <source>Ring vortex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="828"/>
        <source>Ignore Body Panels - RECOMMENDED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="842"/>
        <source>Inertia properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="846"/>
        <source>Use plane inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="851"/>
        <source>Plane Mass =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="852"/>
        <source>X_CoG =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="853"/>
        <source>Z_CoG =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="776"/>
        <source>Wing Loading = 0.033 kg/dm2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="777"/>
        <source>SRe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="778"/>
        <source>RRe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="779"/>
        <source>QInfCl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="535"/>
        <source>Mass must be non-zero for type 2 polars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="807"/>
        <source>3D Panels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="950"/>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="952"/>
        <source>International</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="953"/>
        <source>Imperial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1196"/>
        <source>Vinf.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="823"/>
        <source>Viscous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="824"/>
        <source>Tilt. Geom.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="819"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="995"/>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="999"/>
        <source>Ground Effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1002"/>
        <source>Height =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="893"/>
        <source>Wing Planform</source>
        <oldsource>Wing Planform Area</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="894"/>
        <source>Wing Planform projected on xy plane</source>
        <oldsource>Wing Planform Area projected on xy plane</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="889"/>
        <source>Ref. dimensions for aero coefficients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="895"/>
        <source>User defined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="899"/>
        <source>Ref. area=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="900"/>
        <source>Ref. span length=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="901"/>
        <source>Ref. chord length=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="944"/>
        <source>Air Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="988"/>
        <source>From Altitude and Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1029"/>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1038"/>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1071"/>
        <source>Extra drag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1039"/>
        <source>Extra area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1040"/>
        <source>Extra drag coef.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1067"/>
        <source>Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1068"/>
        <source>Inertia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1069"/>
        <source>Ref. dimensions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1070"/>
        <source>Aero data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1181"/>
        <source>Root Re =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1186"/>
        <source>Tip Re =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1201"/>
        <source>Root Re.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1206"/>
        <source>Tip Re.sqrt(Cl) =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/analysis/wpolardlg.cpp" line="1167"/>
        <source>Wing Loading = </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WingDelegate</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="73"/>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="78"/>
        <source>Uniform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="74"/>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="79"/>
        <source>Cosine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="80"/>
        <source>Sine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingdelegate.cpp" line="81"/>
        <source>-Sine</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WingScaleDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="34"/>
        <source>Scale Wing Dlg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="51"/>
        <source>Span scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="52"/>
        <source>Chord scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="53"/>
        <source>Sweep scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="54"/>
        <source>Twist scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="55"/>
        <source>Area scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="56"/>
        <source>Aspect ratio scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="57"/>
        <source>Taper ratio scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="99"/>
        <source>Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="100"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="101"/>
        <source>Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="163"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingscaledlg.cpp" line="164"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WingSelDlg</name>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingseldlg.cpp" line="44"/>
        <source>BODY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/miarex/design/wingseldlg.cpp" line="55"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WingWidget</name>
    <message>
        <location filename="../xflr5-gui/viewwidgets/wingwidget.cpp" line="287"/>
        <source>Moment ref. location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/wingwidget.cpp" line="357"/>
        <source>Centre of Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/wingwidget.cpp" line="419"/>
        <source>Top transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/viewwidgets/wingwidget.cpp" line="446"/>
        <source>Bottom transition</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XDirect</name>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="192"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="193"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="602"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="914"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1345"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1721"/>
        <source>Cp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="618"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1350"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3553"/>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="716"/>
        <source>Re_Theta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1640"/>
        <source>Not enough threads available for multithreading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1641"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2438"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2597"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3011"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3031"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3044"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3058"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3067"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3076"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3086"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3095"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3104"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3114"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3207"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3230"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3303"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5099"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5117"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1854"/>
        <source>Are you sure you want to delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1855"/>
        <source>and all associated OpPoints and Polars ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1857"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1895"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1920"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2030"/>
        <source>Question</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1889"/>
        <source>Are you sure you want to delete the Operating Point
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1917"/>
        <source>Are you sure you want to delete the polar :
  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="1918"/>
        <source>
 and all the associated OpPoints ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2028"/>
        <source>Are you sure you want to delete polars and OpPoints
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2029"/>
        <source>associated to </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2143"/>
        <source>The foil has been de-rotated by %1 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2178"/>
        <source>The foil has been normalized from %1  to 1.000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2267"/>
        <source>Export Current XFoil Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2269"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2569"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2610"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2722"/>
        <source>Text File (*.txt);;Comma Separated Values (*.csv)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2344"/>
        <source>
Top Side
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2345"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2375"/>
        <source>    x         Hk     Ue/Vinf      Cf        Cd     A/A0       D*       Theta      CTq
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2346"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2376"/>
        <source>x,Hk,Ue/Vinf,Cf,Cd,A/A0,D*,Theta,CTq
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2374"/>
        <source>

Bottom Side
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2419"/>
        <source>Export Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2437"/>
        <source>Could not write to the directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2535"/>
        <source>Export Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2537"/>
        <source>Foil File (*.dat)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2567"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2608"/>
        <source>Export OpPoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2720"/>
        <source>Export Polar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2974"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3196"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2976"/>
        <source>XFoil Polar Format (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3010"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3206"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5098"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5116"/>
        <source>Could not read the file
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3028"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3228"/>
        <source>No Foil with the name </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3029"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3229"/>
        <source>
could be found. The polar(s) will not be stored</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3198"/>
        <source>JavaFoil Polar Format (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3303"/>
        <source>At least two foils are required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3586"/>
        <source>Enter the new name for the foil polar :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3689"/>
        <source>Operating point properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="3705"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4778"/>
        <source>Polar properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2456"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2498"/>
        <source>Polar File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2456"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="2498"/>
        <source>Polar File (*.plr)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4675"/>
        <source>Analysis settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4680"/>
        <source>Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4681"/>
        <source>Store Opp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4682"/>
        <source>Analyze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4687"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4688"/>
        <source>Re</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4697"/>
        <source>Start=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4698"/>
        <source>End=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4699"/>
        <source>D=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4731"/>
        <source>Viscous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4732"/>
        <source>Init BL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4750"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4754"/>
        <source>Displacement thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4755"/>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4756"/>
        <source>Animate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4791"/>
        <source>Graph Curve Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4797"/>
        <source>Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4798"/>
        <source>Flow down style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4799"/>
        <source>If activated:
all changes made to the style of the polar objects will flow down to the operating points
all changes made to the style of the foil objects will flow down to the polars and to the operating points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4829"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4830"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4831"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4832"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="4991"/>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5021"/>
        <source>Enter the foil&apos;s new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5088"/>
        <source>Open XML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5090"/>
        <source>Analysis XML file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5135"/>
        <source>Attaching the analysis to the active foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5141"/>
        <source>No foil to attach the polar to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirect.cpp" line="5175"/>
        <source>Export analysis definition to xml file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XDirectStyleDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="36"/>
        <source>XDirect Styles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="67"/>
        <source>Neutral Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="68"/>
        <source>Boundary Layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="69"/>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="83"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="84"/>
        <source>Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/xdirectstyledlg.cpp" line="85"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XFoilAdvancedDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="29"/>
        <source>XFoil Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="48"/>
        <source>VAccel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="59"/>
        <source>Iteration Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="68"/>
        <source>Re-initialize BLs after an unconverged iteration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="69"/>
        <source>Show full log report for an XFoil analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="70"/>
        <source>Keep Xfoil interface open if analysis errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="74"/>
        <source>Time interval between graph updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="86"/>
        <source>Reset Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="87"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoiladvanceddlg.cpp" line="88"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XFoilAnalysisDlg</name>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="50"/>
        <source>XFoil Analysis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="61"/>
        <source>Iter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="117"/>
        <source>Skip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="118"/>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="322"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="123"/>
        <source>Keep this window opened on errors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="347"/>
        <source> ...some points are unconverged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xdirect/analysis/xfoilanalysisdlg.cpp" line="351"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>XInverse</name>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="121"/>
        <source>x/c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="122"/>
        <source>Q/Vinf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="127"/>
        <source>Q Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="388"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="432"/>
        <source>executing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="428"/>
        <source>Must mark off target segment first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="457"/>
        <source>Converged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="462"/>
        <source>Unconverged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="498"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1418"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2416"/>
        <source> Modified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="530"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="530"/>
        <source>Unrecognized foil format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1048"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1709"/>
        <source>The minimum number of control points has been reached for this spline degree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1254"/>
        <source>Drag the points to modify the spline, Apply, and Execute to generate the new geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1345"/>
        <source>Spline is applied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1559"/>
        <source>Mark target segment for modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1587"/>
        <source>Mark spline endpoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1710"/>
        <source>
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1735"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2473"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2646"/>
        <source>Alpha = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1742"/>
        <source>Cl = </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1790"/>
        <source>Mark target segment for smoothing, or type &apos;Return&apos; to smooth the entire distribution, then Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="1827"/>
        <source>Enter the foil&apos;s new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2055"/>
        <source>                     Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2056"/>
        <source>       Mod.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2063"/>
        <source>Thickness        = %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2069"/>
        <source>Max.Thick.pos.   = %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2075"/>
        <source>Max.Camber       = %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2081"/>
        <source>Max.Camber.pos.  = %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2263"/>
        <source>Cl = %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2335"/>
        <source>Q - Reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2336"/>
        <source>Q - Specification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2337"/>
        <source>Q - Viscous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2344"/>
        <source>Reflected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2467"/>
        <source>Specification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2471"/>
        <source>Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2472"/>
        <source>Cl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2476"/>
        <source>Enter a value + &quot;Enter&quot; to generate the reference QSpec curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2486"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2654"/>
        <source>Modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2491"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2664"/>
        <source>ShowSpline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2492"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2665"/>
        <source>Toggles the visibility of the spline used to modify the QSpec curve.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2494"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2667"/>
        <source>Tangent Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2495"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2668"/>
        <source>When checked, forces the spline to be tangent to the QSpec curve at the 
spline&apos;s endpoints. This is done by constraining the position of the spline&apos;s
second and penultimate control points.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2499"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2672"/>
        <source>New Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2500"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2673"/>
        <source>Click to initiate the definition of a new spline, then select two points
on the QSpec curve.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2503"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2676"/>
        <source>Apply Spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2504"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2677"/>
        <source>Click to modify the QSpec curve using the spline geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2506"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2689"/>
        <source>Reset QSpec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2507"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2690"/>
        <source>Resets the QSpec curve to match the base foil&apos;s geometry.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2509"/>
        <source>Pert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2528"/>
        <source>Smoothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2532"/>
        <source>Smooth QSpec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2541"/>
        <source>Hanning Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2555"/>
        <source>Filter parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2567"/>
        <source>Constraints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2571"/>
        <source>T.E. Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2572"/>
        <source>T.E. Gap dx/c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2573"/>
        <source>T.E. Gap dy/c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2597"/>
        <source>Symmetric foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2622"/>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2719"/>
        <source>Execute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2647"/>
        <source>Cl =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2660"/>
        <source>Mark for modification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2679"/>
        <source>Smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2705"/>
        <source>Foil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2709"/>
        <source>End Point Constraint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2735"/>
        <source>Max Iterations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2797"/>
        <source>Smoothing the entire distribution.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xinverse/xinverse.cpp" line="2802"/>
        <source>Smoothing the selected portion.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gl3dMiarexView</name>
    <message>
        <location filename="../xflr5-gui/xfl3d/gl3dmiarexview.cpp" line="110"/>
        <source>Time =</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xfl3d/gl3dmiarexview.cpp" line="416"/>
        <source>Streamlines calculation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xfl3d/gl3dmiarexview.cpp" line="416"/>
        <location filename="../xflr5-gui/xfl3d/gl3dmiarexview.cpp" line="765"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xflr5-gui/xfl3d/gl3dmiarexview.cpp" line="765"/>
        <source>Velocities calculation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
