

#pragma once


#define MAJOR_VERSION    6
#define MINOR_VERSION    61


//General
#define MAXRECENTFILES         8  /**< Defines the maximum number of file names in the recent file list */

