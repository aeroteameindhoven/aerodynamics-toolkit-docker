#!/bin/sh
printf "\n\nWARNING\n\nIf you experience any problems with starting or running WingHelper on your\ndistribution, here is what you can try:\n\n1. PDF Preview not working\nError message you might be experiencing looks like this:\n\n   evince: error while loading shared libraries: libz.so.1: failed to map\n           segment from shared object\n\nIn order to get rid of that, try removing libz.so.1 and libstdc++.so.6 from\nthe WingHelper libs directory. This will force Wing Helper to use the libz and\nlibstdc++ as installed on your system\n\n2. Further candidate(s) for deletion:\n   - libbsd (can cause issues with libc)\n\n   - libxkbcommon.so.0
   - libOpenGL.so.0
   - libstdc++.so.6
In case this still does not solve your problem(s), please contact me under\nsupport@winghelper.com\n\n"
fullpath=$(readlink -f "$0")
script_dir=$(dirname "$fullpath")
export LD_LIBRARY_PATH="$script_dir/libs"
export QT_PLUGIN_PATH="$script_dir/bin/plugins"
"$script_dir/bin/WingHelper" "$1"
